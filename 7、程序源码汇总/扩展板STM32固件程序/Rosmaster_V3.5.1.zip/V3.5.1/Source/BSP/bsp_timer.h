#ifndef __BSP_TIMER_H__
#define __BSP_TIMER_H__

#include "stm32f10x.h"

void TIM6_Init(void);
void TIM7_Init(void);

#endif
